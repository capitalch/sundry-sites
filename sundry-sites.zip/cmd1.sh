cd /home/jelastic/sundry-sites/capital-seo && node local.js &
cd /home/jelastic/sundry-sites/service-karao-seo && node local.js &
